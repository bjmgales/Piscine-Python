# Bgales Everywhere

This is probably one of, if not the, greatest package ever made. 

See how far you can go with the power of Bgales Everywhere. Sky is the limit. 
Push it to the limit, tutututu.
Bgales is the limit, tutututu. 
Push it to the limit. TANTANTAN.