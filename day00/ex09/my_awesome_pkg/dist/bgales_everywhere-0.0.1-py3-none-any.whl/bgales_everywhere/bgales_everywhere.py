def add_bgales(obj: any):
    obj = "bgales_" + str(obj) + "_bgales"
    return obj
